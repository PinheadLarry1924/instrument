AddCSLuaFile()
DEFINE_BASECLASS("sent_instrument_speaker")

ENT.PrintName = "Small Instrument"
ENT.Author = "Pinhead Larry"
ENT.Information = "A playable Instrument that cannot be carried in the player's inventory"
ENT.Category = "Musical Instruments"

ENT.Editable = false
ENT.Spawnable = true
ENT.AdminOnly = false


ENT.BaseModel = "models/props_c17/streetsign001c.mdl"
