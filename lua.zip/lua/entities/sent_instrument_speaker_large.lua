AddCSLuaFile()
DEFINE_BASECLASS("sent_instrument_speaker")

ENT.PrintName = "Large Instrument"
ENT.Author = "Pinhead Larry"
ENT.Information = "A playable Instrument that cannot be carried in the player's inventory"
ENT.Category = "Musical Instruments"

ENT.Editable = false
ENT.Spawnable = true
ENT.AdminOnly = false


ENT.BaseModel = "models/hunter/tubes/circle4x4.mdl"
